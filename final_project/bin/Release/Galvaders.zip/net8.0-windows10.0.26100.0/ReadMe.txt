Launch Galvaders.exe to start the game

Use the arrow keys to move and space to shoot.
Collect points by killing enemies.

Enemies may drop powerups.
- Purple: multishot
- Yellow: shield
- Green: clone
- Teal: piercing

Gain an extra life every 16000 points

Survive as long as you can. Good Luck!